﻿namespace ProjetoPSI16AFJS
{
    partial class Novo_filme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Novo_filme));
            this.label1 = new System.Windows.Forms.Label();
            this.txtTituloFilme = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPrincipal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nudDuF = new System.Windows.Forms.NumericUpDown();
            this.nudDuT = new System.Windows.Forms.NumericUpDown();
            this.txtRealizador = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNomeTrailer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPub = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtProdutor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudDuF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDuT)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Titulo do  Filme";
            // 
            // txtTituloFilme
            // 
            this.txtTituloFilme.Location = new System.Drawing.Point(109, 39);
            this.txtTituloFilme.Name = "txtTituloFilme";
            this.txtTituloFilme.Size = new System.Drawing.Size(201, 20);
            this.txtTituloFilme.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Duração(min)";
            // 
            // txtPrincipal
            // 
            this.txtPrincipal.Location = new System.Drawing.Point(128, 84);
            this.txtPrincipal.Name = "txtPrincipal";
            this.txtPrincipal.Size = new System.Drawing.Size(201, 20);
            this.txtPrincipal.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ator/Atriz Principal ";
            // 
            // nudDuF
            // 
            this.nudDuF.Location = new System.Drawing.Point(142, 169);
            this.nudDuF.Name = "nudDuF";
            this.nudDuF.Size = new System.Drawing.Size(43, 20);
            this.nudDuF.TabIndex = 6;
            // 
            // nudDuT
            // 
            this.nudDuT.Location = new System.Drawing.Point(485, 167);
            this.nudDuT.Name = "nudDuT";
            this.nudDuT.Size = new System.Drawing.Size(43, 20);
            this.nudDuT.TabIndex = 12;
            // 
            // txtRealizador
            // 
            this.txtRealizador.Location = new System.Drawing.Point(415, 84);
            this.txtRealizador.Name = "txtRealizador";
            this.txtRealizador.Size = new System.Drawing.Size(201, 20);
            this.txtRealizador.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(352, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Realizador";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(377, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Duração Trailer(min)";
            // 
            // txtNomeTrailer
            // 
            this.txtNomeTrailer.Location = new System.Drawing.Point(425, 45);
            this.txtNomeTrailer.Name = "txtNomeTrailer";
            this.txtNomeTrailer.Size = new System.Drawing.Size(201, 20);
            this.txtNomeTrailer.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(352, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Nome Trailer";
            // 
            // txtPub
            // 
            this.txtPub.Location = new System.Drawing.Point(415, 131);
            this.txtPub.Name = "txtPub";
            this.txtPub.Size = new System.Drawing.Size(31, 20);
            this.txtPub.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(352, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Publicidade";
            // 
            // txtProdutor
            // 
            this.txtProdutor.Location = new System.Drawing.Point(99, 131);
            this.txtProdutor.Name = "txtProdutor";
            this.txtProdutor.Size = new System.Drawing.Size(201, 20);
            this.txtProdutor.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Produtor";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(268, 216);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(114, 59);
            this.btnUpdate.TabIndex = 17;
            this.btnUpdate.Text = "UpDate";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // Novo_filme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(637, 287);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtPub);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtProdutor);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.nudDuT);
            this.Controls.Add(this.txtRealizador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNomeTrailer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nudDuF);
            this.Controls.Add(this.txtPrincipal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTituloFilme);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Novo_filme";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Novo_filme";
            this.Load += new System.EventHandler(this.Novo_filme_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudDuF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDuT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTituloFilme;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPrincipal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudDuF;
        private System.Windows.Forms.NumericUpDown nudDuT;
        private System.Windows.Forms.TextBox txtRealizador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNomeTrailer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPub;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtProdutor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnUpdate;
    }
}