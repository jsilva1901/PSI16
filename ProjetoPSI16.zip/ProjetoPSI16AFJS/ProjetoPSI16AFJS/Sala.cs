﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoPSI16AFJS
{
    public partial class Sala : Form
    {
        SqlConnection con = new SqlConnection(Properties.Settings.Default.Conn);
        SqlDataAdapter SqlDAdapter;
        DataSet dgv;
        public Sala()
        {
            InitializeComponent();
        }

        private void Sala_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("select * from Sala", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dgvSala.VirtualMode = false;
                dgvSala.Columns.Clear();
                dgvSala.AutoGenerateColumns = true;
                dgvSala.DataSource = ds.Tables[0];
                dgvSala.Refresh();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Inserir_Filme insFilme = new Inserir_Filme();
            insFilme.Show();


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            dgvSala.ReadOnly = false;
            dgvSala.AllowUserToAddRows = true;
            dgvSala.AllowUserToDeleteRows = true;


             SqlDAdapter = new SqlDataAdapter("Select * from Sala", con);

            dgv = new DataSet();

            SqlDAdapter.Fill(dgv, "Sala");
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
          

            SqlCommandBuilder cmdBd = new SqlCommandBuilder(SqlDAdapter);

            SqlDAdapter.Update(dgv, "Sala");

            MessageBox.Show("Informação atualizada", "DataGridView", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
